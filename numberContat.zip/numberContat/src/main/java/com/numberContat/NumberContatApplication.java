package com.numberContat;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NumberContatApplication {

	public static void main(String[] args) {
		SpringApplication.run(NumberContatApplication.class, args);
	}
}
